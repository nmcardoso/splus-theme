  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="<?php bloginfo('template_url'); ?>/assets/script/jquery-3.3.1.slim.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/script/popper-1.14.7.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/script/bootstrap-4.3.1.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/script.js"></script>
</body>

</html>